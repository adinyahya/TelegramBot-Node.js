// telegram token
var token = '813583012:AAE9II9NUSWHvbhi75dVgkT7TsgAXmZbZpM'
// firebase config
var config = {
    apiKey: "AIzaSyB39yHrUy1LejV1hYO3m2WqVuiHCpQNLm0",
    authDomain: "pecycoin-fd9c5.firebaseapp.com",
    databaseURL: "https://pecycoin-fd9c5.firebaseio.com",
    projectId: "pecycoin-fd9c5",
    storageBucket: "pecycoin-fd9c5.appspot.com",
    messagingSenderId: "1031896387903",
    appId: "1:1031896387903:web:15b13dfb12c8c238"

};

exports.token = token;
exports.firebase_config = config;